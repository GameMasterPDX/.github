1. Original Creator: Kojimkj

2. Contributor: Linkstorm Z

I managed to create the graphics of the grinder..the giant hammer bro, Toad, wiggler,
some corrections of the design of the coins(hud.bmp) , the whole underground and underwater level,
activating the ability to jump walls, a small change of the sprite that appears when hitting the blocks..
background..and the double pipe

Linkstorm Z

---

MarioHammer,MarioCloud sprite

- All credit goes to SFMB (MM) beta testers Andot#5171 and Annanxy#1941